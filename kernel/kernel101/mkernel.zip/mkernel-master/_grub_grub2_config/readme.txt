Sample grub.cfg for GRUB and GRUB2.
Thanks to Rubén Laguna for the providing GRUB2 config.